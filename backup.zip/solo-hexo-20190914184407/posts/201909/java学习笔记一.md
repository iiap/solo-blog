title: java学习笔记一
date: '2019-09-14 01:58:05'
updated: '2019-09-14 01:58:05'
tags: [java]
permalink: /articles/2019/09/14/1568397485304.html
---
![](https://img.hacpai.com/bing/20190527.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 异常
#### 异常小练习
>假设有一个方法 public int method()， 会返回一个整数
>在这个方法中有try catch 和 finally.
>try 里返回 1
>catch 里 返回 2
>finally 里 返回3
>那么，这个方法到底返回多少？

==答案：3==
`实例`
```java
public class ExceptionDemo2 {
	
	public static int method1() {
		
		try {
			return 1;
		} catch (Exception e) {
			return 2;
		}finally {
			return 3;
		} 
	}
	public static void main(String[] args) {
		System.out.println(method1());
	}
}
```
#### finally语句块不能执行的情况
finally语句块在正常情况下都是一定会执行的，即使在finally语句块之前有return语句(如上面的练习题中一样)，但在一些特殊情况下，finally语句并不会执行，如下：
- 在finally语句块中发生了异常。
- 在前面的代码中用了System.exit()退出程序。
- 程序所在的线程死亡。
- 关闭CPU。

#### throw和throws的区别
throws与throw这两个关键字接近，不过意义不一样，有如下区别：
- throws 出现在方法声明上，而throw通常都出现在方法体内。
- throws 表示出现异常的一种可能性，并不一定会发生这些异常；throw则是抛出了异常，执行throw则一定抛出了某个异常对象。

#### 异常的分类
###### 错误
属于 JVM 层次的严重错误 ，导致 JVM 无法继续执行
###### 运行时异常(运行期异常)
运行时异常RuntimeException指：`不是必须进行try catch的异常 `，在编写代码的时候，依然可以使用try catch throws进行处理，与可查异常不同之处在于，`即便不进行try catch，也不会有编译错误`。

Java之所以会设计运行时异常的原因之一，是因为下标越界，空指针这些运行时异常太过于普遍，如果都需要进行捕捉，代码的可读性就会变得很糟糕。

==常见的运行时异常==
- NullPointerException （空指针异常）
- IndexOutOfBoundsException （下标越界异常）
- ArithmeticException（算术异常）
- ClassCastException （类转换异常）
- IllegalArgumentException （非法参数异常）
- SecurityException （安全异常）

###### 可查异常(编译器异常)
必须进行处理的异常，要么try catch住,要么往外抛，谁调用，谁处理，比如 FileNotFoundException，如果不处理，编译器，就不让你通过
