title: Eclipse常用快捷键
date: '2019-09-14 01:59:08'
updated: '2019-09-14 01:59:08'
tags: [软件使用]
permalink: /articles/2019/09/14/1568397548409.html
---
![](https://img.hacpai.com/bing/20181116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


|快捷键| 作用 |
|:--|:--|
|`Alt+/` | 自动补全代码或者提示代码 |
|`Ctrl+2,L`   |  接收方法返回值   |
| `Ctrl+shift+F` | 格式化代码 |
|`Ctrl+D`   | 删除当前行 |
| `Ctrl+Q`  |  定位到最后编辑的地方   |
| `Ctrl+L`  |  定位到某一行   |
| `Ctrl+T`  |  快速显示当前类的继承结构   |
| `Ctrl+E`  | 快速转换编辑器 |
|`Ctrl+W`   |  关闭当前Editer   |
|`Ctrl+K`   |  参照选中的Word快速定位到下一个   |
| `Ctrl+page down`或`ctrl+page up`<br/>`Alt+方向键左右`   |选项卡之间快速切换  |
| `Ctrl+/`   | 自动注释当前行或者选择的多行(使用`//`注释) |
| `Ctrl+shift+/`   | 自动注释掉选择的代码块(使用`/* */注释`) |
| `Alt+方向键上下`   |把当前行内容把上或下移动  |
| `Ctrl+O`   | 快速outline视图,查看当前类中的方法与属性 |
| `Ctrl+shift+R`   |  打开资源列表|
|  `Ctrl+shift+O`  |自动引入包和删除无用包  |
|  `Alt+Shift+R` | 重命名    |
| `Alt+Shift+M`  |  抽取方法	   |



