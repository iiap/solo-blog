title: freeswitch常用命令
date: '2019-09-14 02:00:01'
updated: '2019-09-14 02:00:01'
tags: [FreeSwitch]
permalink: /articles/2019/09/14/1568397601584.html
---
![](https://img.hacpai.com/bing/20190428.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 使用freeswitch过程中经常使用的命令、操作
---

##### 查看进程
```
ps -e | grep freeswitch   //显示所有进程，并显示包含freeswitch字符的信息
```

#### 启动freeswitch
```
freeswitch -nc      //将freeswitch启动到后台模式，没有控制台
```

#### 关闭freeswtich
```
freeswitch -stop
```

#### 使用fs_cli连接并控制freeswitch
```
fs_cli
```

#### 快速创建一个用户配置文件
```
//将1000.xml中的所有“1000”字符串替换为“2019”字符串，
//并将命令的输出重定向到2019.xml
sed -e "s/1000/2019/" 1000.xml > 2019.xml
```

#### 查看用户的注册信息
```
sofia status profile internal reg     // 显示多少用户已注册，内网
sofia status profile external reg     // 显示用户的注册数量及注册的详细信息，外网
```

#### 重新加载配置文件
```
reloadxml  或者	F6 快捷键
```

#### 获取SIP消息（抓包）
```
sofia global siptrace on           // 打开 trace
sofia global siptrace off          // 关闭 trace
```
#### 关闭 log
```
/nolog
```

#### 设置 log 级别
```
/log 数字   或者  /log info    或者   /log debug
```

